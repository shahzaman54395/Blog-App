package pk.edu.szabist.blogapp.utils

object Configuration {
    const val BASE_URL = "http://10.0.131.160:5001/BlogApp/";
}
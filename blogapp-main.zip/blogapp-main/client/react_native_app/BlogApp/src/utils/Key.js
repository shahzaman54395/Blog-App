class Key {

    static USER = 'user';
    static ALL_BLOGS = 'allblogs';
    static MY_BLOGS = 'myblogs';
    static BLOG = 'blog';
}
export default Key;
export default class Configuration {
    static BASE_URL = 'http://192.168.43.89/BlogApp';
}